Project: CampusOfKings-bad
Authors: Maria Jump

This project is a simple framework for a text adventure game. In this version,
it has a few rooms and the ability for a player to walk between these rooms.
That's all.

This version of the game contains some very bad class design. It should NOT
be used as a basis for extending the project without fixing these design
problems. It serves as an example to discuss good and bad design.

We will fix the problems with this project through the next couple of labs which
walk students through fixing bad design decisions and give them an opportunity
to become familiar with the existing code.
