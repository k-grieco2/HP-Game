# project-k-grieco2
project-k-grieco2 created by GitHub Classroom

Hello!

This repository contains all files needed to play the text-based adventure game "Harry Potter and the Barren Halls of Ivy".java
This game has been created.

Come back later to see the list of in-game commands avaialable for use, as well as some helpful game hints.
